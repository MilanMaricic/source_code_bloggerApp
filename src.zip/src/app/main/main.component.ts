import { Component, OnInit } from '@angular/core';
import { BloggersService } from '../bloggers.service';
import { Blogger } from '../blogger';
import { Store } from '@ngrx/store';
import * as BloggersAction from '../store/bloggers.actions';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(private bloggersService: BloggersService,
    private store: Store<{ bloggers: { bloggers: Blogger[] } }>
    ) { }

  ngOnInit() {
    this.getAllBloggers();
  }

  getAllBloggers() {
    this.bloggersService.getAllBloggers()
      .subscribe(
        (bloggers) => {
          this.store.dispatch(new BloggersAction.AddBloggers(bloggers));
        }
      )
;
  }
}


