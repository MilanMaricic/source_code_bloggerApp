import { Component, OnInit } from '@angular/core';
import { PostService } from '../../post.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  post: { id: number, title: string, category: string, datePosted: string };
  condition: boolean = false;

  constructor(private postService: PostService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.postService.getAllPosts()
      .subscribe(
        (posts) => {
          for (var index in posts) {
              if (posts[index].id == id) {
                this.post = posts[index];
                this.condition = true;
                break;
              }
            }
        }
      );
    this.route.params
      .subscribe(
        (params: Params) => {
          const id = params['id'];
          console.log(id);
          this.postService.getAllPosts()
            .subscribe(
              (posts) => {
                for (var index in posts) {
                  if (posts[index].id == id) {
                    this.post = posts[index];
                    this.condition = true;
                    break;
                  }
                }
              }
            );
        }
      );
  }
}
