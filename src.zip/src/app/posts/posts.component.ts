import {
  Component, OnInit, 
  //trigger,
  //state,
  //style,
  TRANSLATIONS,
 // animate,
  //keyframes
} from '@angular/core';
import { PostService } from '../post.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { debugOutputAstAsTypeScript } from '@angular/compiler';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
 
})
export class PostsComponent implements OnInit {

  posts: { id: number, title: string, category: string, datePosted: string }[] = [];

  addForm: FormGroup;

  constructor(private postService: PostService) { }

  ngOnInit() {
    this.addForm = new FormGroup({
      'title': new FormControl(null, Validators.required),
      'category': new FormControl(null, [Validators.required]),
      'date': new FormControl(null, [Validators.required])
    });
    this.postService.getAllPosts()
      .subscribe(
        (posts) => {
          this.posts = posts != null ? posts : [];
        }
      );
  }

  deletePost(id: number) {
    this.posts = this.posts.filter(posts => posts.id !== id);
    this.postService.savePosts(this.posts)
      .subscribe();
  }

  submit() {
    const postIds = this.posts.map(post => post.id);
    const id = postIds.indexOf(Math.max(...postIds)) + 1;

    const newPost = {
      id: id, title: this.addForm.value.title,
      category: this.addForm.value.category, datePosted: this.addForm.value.date
    };
    this.posts.push(newPost);
    this.postService.savePosts(this.posts)
      .subscribe();

    this.addForm.reset();
  }
}
