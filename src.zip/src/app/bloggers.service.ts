import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Blogger } from './blogger';
import { AuthService } from './auth.service';

@Injectable()
export class BloggersService {
    constructor(private http: HttpClient,
        private authService: AuthService) { }
    headers = new HttpHeaders().set('Content-Type', 'application/json');

    getAllBloggers() {
        const token = this.authService.getIdToken();
        return this.http.get<Blogger[]>('https://bloggers-base.firebaseio.com/data.json?auth=' + token,{  //https://bloggers-base.firebaseio.com/
            headers: this.headers
        });
    }

    saveBlogger(bloggers) {
        const token = this.authService.getIdToken();
        return this.http.put('https://bloggers-base.firebaseio.com/data.json?auth=' + token, bloggers, { //https://bloggers-base.firebaseio.com/
            headers: this.headers
        });
    }
}

