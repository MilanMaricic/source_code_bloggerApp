import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable()
export class PostService {
    constructor(private http: HttpClient,
        private authService: AuthService) { }
    headers = new HttpHeaders().set('Content-Type', 'application/json');

    getAllPosts() {
        const token = this.authService.getIdToken();
        return this.http.get<any[]>('https://bloggers-base.firebaseio.com/posts.json?auth=' + token, { //https://bloggers-base.firebaseio.com/
            headers: this.headers
        });
    }

    savePosts(posts) {
        const token = this.authService.getIdToken();
        return this.http.put('https://bloggers-base.firebaseio.com/posts.json?auth=' + token, posts, { //https://bloggers-base.firebaseio.com/
            headers: this.headers
        });
    }
}

