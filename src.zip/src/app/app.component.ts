import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor(private authService: AuthService,
    private router: Router) { }

  ngOnInit() {
    firebase.initializeApp({
      apiKey: 'AIzaSyA9nQ-BO56xLl0AIQ4krekNVYi4sTx0zvY',
      authDomain: 'bloggers-base.firebaseapp.com',
    });
  }

  signOut() {
    this.authService.signout();
    this.router.navigate(['/signin']);
  }

}
