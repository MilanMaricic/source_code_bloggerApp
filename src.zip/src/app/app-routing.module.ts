import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { PostsComponent } from './posts/posts.component';
import {SigninComponent} from './auth/signin/signin.component';
import {SignupComponent} from './auth/signup/signup.component';
import { GuardService } from './guard.service';
import { PostComponent } from './posts/post/post.component';

const appRoutes: Routes = [
    {path: '', component: MainComponent, canActivate: [GuardService]},
    {path: 'posts', component: PostsComponent, canActivate: [GuardService], children: [
        {path: ':id', component: PostComponent}
    ]},
    {path: 'signup', component: SignupComponent},
    {path: 'signin', component: SigninComponent},
    {path: 'pagenotfound' , component: PagenotfoundComponent},
    {path: '**' , redirectTo: '/pagenotfound'}
  ];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes)
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {

}
