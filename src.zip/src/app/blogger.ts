export class Blogger {
    name: string;
    about: string;
    email: string;

    constructor(name: string, email: string, about: string ) {
        this.name = name;
        this.about = about;
        this.email = email;
    }
}