import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddbloggerComponent } from './addblogger.component';

describe('AddbloggerComponent', () => {
  let component: AddbloggerComponent;
  let fixture: ComponentFixture<AddbloggerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddbloggerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddbloggerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
