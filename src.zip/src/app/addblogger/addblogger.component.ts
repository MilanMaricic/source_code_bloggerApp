import { Component, OnInit, ViewChild } from '@angular/core';
import { BloggersService } from '../bloggers.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Blogger } from '../blogger';
import { NgForm } from '@angular/forms';
import * as BloggersAction from '../store/bloggers.actions';

@Component({
  selector: 'app-addblogger',
  templateUrl: './addblogger.component.html',
  styleUrls: ['./addblogger.component.css']
})
export class AddbloggerComponent implements OnInit {

  bloggersState: Observable<{ bloggers: Blogger[] }>;
  @ViewChild('f') form: NgForm;

  constructor(private bloggersService: BloggersService,
    private store: Store<{ bloggers: { bloggers: Blogger[] } }>) { }

  ngOnInit() {
    this.bloggersState = this.store.select('bloggers');
  }

  addBlogger() {
    this.store.dispatch(new BloggersAction.AddBlogger(new Blogger(this.form.value.name, this.form.value.email, this.form.value.about)));
    this.bloggersState.subscribe(
      (state) => {
        this.bloggersService.saveBlogger(state.bloggers).subscribe();
      }
    );
    this.form.reset();
  }

}
