import { Component, OnInit } from '@angular/core';
import { Blogger } from '../blogger';
import { BloggersService } from '../bloggers.service';
import { NgForm } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import * as BloggersAction from '../store/bloggers.actions';

@Component({
  selector: 'app-bloggers',
  templateUrl: './bloggers.component.html',
  styleUrls: ['./bloggers.component.css']
})
export class BloggersComponent implements OnInit {

  bloggerState: Observable<{ bloggers: Blogger[] }>;

  constructor(private bloggersService: BloggersService,
    private store: Store<{ bloggers: { bloggers: Blogger[] } }>) { }

  ngOnInit() {
    this.bloggerState = this.store.select('bloggers');
  }

  addBlogger(form: NgForm) {
    this.store.dispatch(new BloggersAction.AddBlogger(
      new Blogger(form.value.name, form.value.email, form.value.about)));

    this.bloggerState.subscribe(
      (blog) => {
        this.bloggersService.saveBlogger(blog.bloggers).subscribe();
      }
    );
    form.reset();
  }

}
