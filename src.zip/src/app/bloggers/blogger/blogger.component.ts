import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Blogger } from '../../blogger';
import { BloggersService } from '../../bloggers.service';
import { Store } from '@ngrx/store';
import * as BloggersAction from '../../store/bloggers.actions';
import { Observable } from 'rxjs';
import { NgForm } from '@angular/forms';

declare var $: any;

@Component({
  selector: 'app-blogger',
  templateUrl: './blogger.component.html',
  styleUrls: ['./blogger.component.css']
})
export class BloggerComponent implements OnInit {

  @Input() blogger: Blogger;
  @Input() index: number; 
  modalIndex: number;

  //@ViewChild('modal') blogModal;

  bloggersState: Observable<{ bloggers: Blogger[] }>;

  constructor(private bloggersService: BloggersService,
    private store: Store<{ bloggers: { bloggers: Blogger[] } }>) { }

  ngOnInit() {
    this.bloggersState = this.store.select('bloggers');
    this.modalIndex =this.index;
  }

  changeBlogger(form: NgForm) {
    this.store.dispatch(new BloggersAction.
      EditBlogger({
        index: this.index,
        blogger: new Blogger(form.value.name, form.value.email, form.value.about)
      }));

    this.bloggersState.subscribe(
      (blog) => {
        this.bloggersService.saveBlogger(blog.bloggers).subscribe();
      }
    );
    form.reset();
  }


  deleteBlogger() {
    this.store.dispatch(new BloggersAction.DeleteBlogger(this.index));
    this.bloggersState.subscribe(
      (blog) => {
        this.bloggersService.saveBlogger(blog.bloggers).subscribe();
      }
    );
  }
}
  
