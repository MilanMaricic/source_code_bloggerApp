import * as BloggersActions from './bloggers.actions';
import {Blogger} from '../blogger';

const initialState = {
    bloggers : []
};

export function bloggersReducer(state = initialState, action: BloggersActions.Actions) {
    switch (action.type) {
        case BloggersActions.ADD_BLOGGER:
            return {
                ...state,
                bloggers: [...state.bloggers, action.payload]
            };
        case BloggersActions.DELETE_BLOGGER: 
            const oldBloggers = [...state.bloggers];
            oldBloggers.splice(action.payload, 1);
            return {
                ...state,
                bloggers: oldBloggers
            };
        case BloggersActions.EDIT_BLOGGER:
            const beforeEditingBloggers = [...state.bloggers];
            beforeEditingBloggers[action.payload.index] = action.payload.blogger;
            console.log(action.payload.index);
            return{
                ...state,
                bloggers: beforeEditingBloggers
            };
        case BloggersActions.ADD_BLOGGERS:
            return {
                ...state,
                bloggers: action.payload
            };
        default:
            return state;
    }
}
