import { Action } from '@ngrx/store';
import { Blogger } from '../blogger';

export const ADD_BLOGGER = 'ADD_BLOGGER';
export const DELETE_BLOGGER = 'DELETE_BLOGGER';
export const EDIT_BLOGGER = 'EDIT_BLOGGER';
export const ADD_BLOGGERS = 'ADD_BLOGGERS';

export class AddBlogger implements Action {
    readonly type = ADD_BLOGGER;

    constructor(public payload: Blogger) {}
}

export class EditBlogger implements Action {
    readonly type = EDIT_BLOGGER;

    constructor(public payload: {index: number , blogger: Blogger}) {}
}

export class DeleteBlogger implements Action {
    readonly type = DELETE_BLOGGER;

    constructor(public payload: number) {}
}

export class AddBloggers implements Action {
    readonly type = ADD_BLOGGERS;

    constructor(public payload: Blogger[]) {}
}

export type Actions = AddBlogger | DeleteBlogger | EditBlogger | AddBloggers;
