import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import {HttpClientModule} from '@angular/common/http';
import { BloggersComponent } from './bloggers/bloggers.component';
import { BloggerComponent } from './bloggers/blogger/blogger.component';
import { SigninComponent } from './auth/signin/signin.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AddbloggerComponent } from './addblogger/addblogger.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { PostsComponent } from './posts/posts.component';
import { PostComponent } from './posts/post/post.component';
import { BloggersService } from './bloggers.service';
import { AuthService } from './auth.service';
import { GuardService } from './guard.service';
import { PostService } from './post.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { bloggersReducer } from './store/bloggers.reducers';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    BloggersComponent,
    BloggerComponent,
    SigninComponent,
    SignupComponent,
    AddbloggerComponent,
    PagenotfoundComponent,
    PostsComponent,
    PostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    StoreModule.forRoot({bloggers:bloggersReducer}),
    BrowserAnimationsModule
  ],
  providers: [BloggersService,AuthService,GuardService,PostService],
  bootstrap: [AppComponent]
})
export class AppModule { }
